import Link from 'next/link';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

/**
 * Pricing page.
 *
 * Outlines two simple subscription plans for accessing the
 * dashboards and forecasts. In a real implementation, the Pay
 * buttons would initiate a payment flow with Stripe or PayPal.
 * Here they simply link to the dashboards page for demonstration.
 */
export default function Pricing() {
  return (
    <>
      <Navbar />
      <main className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-serif text-gold mb-8">Pricing Plans</h1>
        <div className="grid md:grid-cols-2 gap-8">
          {/* Monthly plan */}
          <div className="bg-midnight border border-slate rounded-lg p-6 flex flex-col items-center text-center">
            <h2 className="text-2xl font-serif text-gold mb-4">Monthly Access</h2>
            <p className="text-slate mb-4">Access to all dashboards and forecasts for one month.</p>
            <p className="text-4xl font-serif text-gold mb-6">30 TND</p>
            <Link href="/dashboards" className="bg-gold text-midnight font-semibold py-3 px-6 rounded-full hover:bg-white hover:text-midnight">
              Pay &amp; Access
            </Link>
          </div>
          {/* Quarterly plan */}
          <div className="bg-midnight border border-slate rounded-lg p-6 flex flex-col items-center text-center">
            <h2 className="text-2xl font-serif text-gold mb-4">Quarterly Access</h2>
            <p className="text-slate mb-4">Access to all dashboards and forecasts for three months.</p>
            <p className="text-4xl font-serif text-gold mb-6">80 TND</p>
            <Link href="/dashboards" className="bg-gold text-midnight font-semibold py-3 px-6 rounded-full hover:bg-white hover:text-midnight">
              Pay &amp; Access
            </Link>
          </div>
        </div>
        <p className="text-slate text-sm mt-12">Payments are processed via a secure provider (Stripe/PayPal). After successful payment, you will be redirected to the dashboards.</p>
      </main>
      <Footer />
    </>
  );
}