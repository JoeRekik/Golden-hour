import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

/**
 * About page.
 *
 * Contains a placeholder for a longer biography of Youssef Rekik,
 * a disclaimer clarifying the educational nature of the project,
 * and a simple contact form. The form does not submit
 * anywhere—it serves as a placeholder for future integration.
 */
export default function About() {
  return (
    <>
      <Navbar />
      <main className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-serif text-gold mb-8">About Golden Hour</h1>
        <section className="mb-12">
          <h2 className="text-2xl font-serif text-gold mb-4">About Me</h2>
          <p className="text-slate mb-6">
            {/* Insert long bio for Youssef Rekik here. */}
          </p>
        </section>
        <section className="mb-12">
          <h2 className="text-2xl font-serif text-gold mb-4">Disclaimer</h2>
          <p className="text-slate">
            Golden Hour provides educational analytics based on publicly available data. It does not offer investment advice, nor does it accept orders or funds. For trading activities, always consult a licensed intermediary and conduct your own due diligence.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-serif text-gold mb-4">Contact Us</h2>
          <form className="max-w-md">
            <label className="block mb-2 text-slate" htmlFor="name">Name</label>
            <input id="name" type="text" className="w-full mb-4 p-2 rounded bg-midnight border border-slate text-white" />
            <label className="block mb-2 text-slate" htmlFor="email">Email</label>
            <input id="email" type="email" className="w-full mb-4 p-2 rounded bg-midnight border border-slate text-white" />
            <label className="block mb-2 text-slate" htmlFor="message">Message</label>
            <textarea id="message" rows={4} className="w-full mb-4 p-2 rounded bg-midnight border border-slate text-white"></textarea>
            <button type="submit" className="bg-gold text-midnight font-semibold py-2 px-4 rounded hover:bg-white hover:text-midnight">Send</button>
          </form>
        </section>
      </main>
      <Footer />
    </>
  );
}