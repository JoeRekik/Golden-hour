import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

/**
 * Forms page.
 *
 * Presents English versions of three client documents: the
 * account opening form, order ticket, and fees &amp; commissions
 * summary. Each section lists relevant fields and includes a
 * Download PDF button for future integration. A disclaimer at
 * the bottom clarifies that these templates are for educational
 * use only.
 */
export default function Forms() {
  return (
    <>
      <Navbar />
      <main className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-serif text-gold mb-8">Client Documents (Golden Hour)</h1>
        <p className="text-slate mb-8">Below are English versions of the forms you showed me—logo removed, neutral wording, and branded “Golden Hour”.</p>
        <div className="space-y-12">
          {/* Account Opening Form */}
          <section className="bg-midnight border border-slate rounded-lg p-6">
            <h2 className="text-2xl font-serif text-gold mb-4">Account Opening Form (Securities Account)</h2>
            <ul className="list-disc list-inside text-slate space-y-1">
              <li>Personal Details: Full Name, Nationality, Date of Birth, Profession</li>
              <li>ID: Type (ID/Passport), Number, Issue Date, Issue Place</li>
              <li>Address: Street, City, Postal Code, Country, Phone, Email</li>
              <li>Professional Address (optional): Company, Address, Phone, Email</li>
              <li>Acting as: [ ] On my own behalf [ ] On behalf of a legal person (company)</li>
              <li>Company (if applicable): Legal Name, Registry Number, Tax ID, Address, City, Country, Email</li>
              <li>Representative (if applicable): Full Name, Relationship, ID details</li>
              <li>Account Type requested: [ ] Standard [ ] Custody-Only [ ] Discretionary</li>
              <li>Risk Profile: [ ] Prudent [ ] Moderate [ ] High</li>
              <li>Investment Objective: [ ] Build Wealth [ ] Diversify Savings [ ] Fiscal Advantage</li>
              <li>Horizon: [ ] Short [ ] Medium [ ] Long</li>
              <li>Market Knowledge: [ ] Good [ ] Average [ ] None</li>
              <li>How did you hear about us? [ ] Referral [ ] Online [ ] Advertising</li>
              <li>Consent: I agree to the Terms &amp; Privacy Policy.</li>
              <li>Signature &amp; Date</li>
            </ul>
            <div className="mt-4">
              <a href="#" className="bg-gold text-midnight font-semibold py-2 px-4 rounded hover:bg-white hover:text-midnight">Download PDF</a>
            </div>
          </section>

          {/* Order Ticket */}
          <section className="bg-midnight border border-slate rounded-lg p-6">
            <h2 className="text-2xl font-serif text-gold mb-4">Order Ticket (Buy/Sell)</h2>
            <ul className="list-disc list-inside text-slate space-y-1">
              <li>Client Code</li>
              <li>Name &amp; Address</li>
              <li>Acting on behalf of: Self / Other (specify)</li>
              <li>Order Type: [ ] Buy [ ] Sell</li>
              <li>Instrument (Issuer/Ticker)</li>
              <li>Number of Shares</li>
              <li>Price Type: [ ] Market (ATP) [ ] At Opening [ ] Limit (specify) [ ] Best Opposite</li>
              <li>Stops (optional): Stop Loss, Stop Limit (trigger/limit)</li>
              <li>Validity: [ ] Day [ ] Good-till-Date (date) [ ] Good-till-Cancel (365 days)</li>
              <li>Settlement / Proceeds: [ ] Cash [ ] Bank Transfer (Bank/IBAN) [ ] Other</li>
              <li>Other Instructions</li>
              <li>Date, Time, Client Signature</li>
            </ul>
            <div className="mt-4">
              <a href="#" className="bg-gold text-midnight font-semibold py-2 px-4 rounded hover:bg-white hover:text-midnight">Download PDF</a>
            </div>
          </section>

          {/* Fees & Commissions */}
          <section className="bg-midnight border border-slate rounded-lg p-6">
            <h2 className="text-2xl font-serif text-gold mb-4">Fees &amp; Commissions</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full text-slate">
                <thead>
                  <tr>
                    <th className="border-b border-slate px-4 py-2 text-left">Item</th>
                    <th className="border-b border-slate px-4 py-2 text-left">Amount / Rate</th>
                    <th className="border-b border-slate px-4 py-2 text-left">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="border-b border-slate px-4 py-2">Account Opening</td>
                    <td className="border-b border-slate px-4 py-2">100 TND (example)</td>
                    <td className="border-b border-slate px-4 py-2">One-time</td>
                  </tr>
                  <tr>
                    <td className="border-b border-slate px-4 py-2">Brokerage</td>
                    <td className="border-b border-slate px-4 py-2">0.5%</td>
                    <td className="border-b border-slate px-4 py-2">Min may apply</td>
                  </tr>
                  <tr>
                    <td className="border-b border-slate px-4 py-2">Account Maintenance</td>
                    <td className="border-b border-slate px-4 py-2">Monthly/Annual</td>
                    <td className="border-b border-slate px-4 py-2">If applicable</td>
                  </tr>
                    <tr>
                    <td className="border-b border-slate px-4 py-2">Dividend Handling</td>
                    <td className="border-b border-slate px-4 py-2">3% of coupon</td>
                    <td className="border-b border-slate px-4 py-2">If applicable</td>
                  </tr>
                  <tr>
                    <td className="border-b border-slate px-4 py-2">Transfer Out</td>
                    <td className="border-b border-slate px-4 py-2">30 TND</td>
                    <td className="border-b border-slate px-4 py-2">Per transfer</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div className="mt-4">
              <a href="#" className="bg-gold text-midnight font-semibold py-2 px-4 rounded hover:bg-white hover:text-midnight">Download PDF</a>
            </div>
          </section>
        </div>
        <p className="text-slate text-sm mt-12">Note: These forms are templates for demos and education. Golden Hour is not a broker, does not accept orders or funds. For trading, contact a licensed intermediary.</p>
      </main>
      <Footer />
    </>
  );
}