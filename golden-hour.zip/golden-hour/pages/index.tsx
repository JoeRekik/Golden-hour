import Link from 'next/link';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

/**
 * Home page of the Golden Hour site.
 *
 * Introduces the project with a hero section, quick call-to-action
 * buttons, and overview sections about Youssef Rekik and the
 * Golden Hour concept. Placeholder text is provided where the
 * user will later insert a personal introduction.
 */
export default function Home() {
  return (
    <>
      <Navbar />
      <main className="container mx-auto px-4 py-12">
        {/* Hero section */}
        <section className="text-center">
          <h1 className="text-4xl md:text-5xl font-serif text-gold mb-4">The Golden Hour — BVMT &amp; Bitcoin Insights</h1>
          <p className="text-lg text-slate max-w-2xl mx-auto mb-8">
            A clean, data-driven way to spot high-opportunity trading windows using CRISP-DM, Power BI dashboards, and monthly forecasts.
          </p>
          <div className="space-x-4">
            <Link href="/dashboards" className="bg-gold text-midnight font-semibold py-3 px-6 rounded-full hover:bg-white hover:text-midnight">
              View Dashboards
            </Link>
            <Link href="/pricing" className="bg-transparent border border-gold text-gold font-semibold py-3 px-6 rounded-full hover:bg-gold hover:text-midnight">
              Get Access
            </Link>
          </div>
        </section>
        {/* About Youssef */}
        <section className="mt-16 max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-serif text-gold mb-4">About Youssef Rekik</h2>
          <p className="text-slate mb-8">
            {/* Youssef Rekik introduction goes here. The user will supply this text later. */}
          </p>
          <h2 className="text-2xl font-serif text-gold mb-4">About Golden Hour</h2>
          <p className="text-slate">
            Golden Hour is a project that identifies peak and trough periods for smarter timing in both the Tunisian BVMT stock market and Bitcoin. By applying advanced analytics and the CRISP-DM methodology, it offers clear visual dashboards and forecasts to help you navigate market cycles with confidence.
          </p>
        </section>
      </main>
      <Footer />
    </>
  );
}