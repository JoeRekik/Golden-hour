import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import PowerBIFrame from '../components/PowerBIFrame';
import Image from 'next/image';

/**
 * Dashboards page.
 *
 * Presents two interactive Power BI dashboards (Bitcoin and BVMT
 * stocks) along with accompanying forecast images and basic
 * accuracy metrics. The page is organised into sections for each
 * asset. Replace the `stocksUrl` variable with your actual BVMT
 * embed link once available.
 */
export default function Dashboards() {
  // Secure embed URLs for your Power BI reports.
  const btcUrl =
    'https://app.powerbi.com/reportEmbed?reportId=f8dfb7b3-1433-4bcb-8647-3bcbce4116d3&autoAuth=true&ctid=604f1a96-cbe8-43f8-abbf-f8eaf5d85730';
  const stocksUrl =
    'https://app.powerbi.com/reportEmbed?reportId=f8dfb7b3-1433-4bcb-8647-3bcbce4116d3&autoAuth=true&ctid=604f1a96-cbe8-43f8-abbf-f8eaf5d85730'; // Replace with your BVMT report link

  return (
    <>
      <Navbar />
      <main className="container mx-auto px-4 py-12">
        <h1 className="text-3xl font-serif text-gold mb-8">Dashboards</h1>
        {/* Bitcoin section */}
        <section className="mb-16">
          <h2 className="text-2xl font-serif text-gold mb-4">Bitcoin Dashboard</h2>
          <PowerBIFrame url={btcUrl} title="Bitcoin Dashboard" />
          <p className="text-slate mb-4">
            Interpretation: This dashboard provides an interactive view of Bitcoin market data, highlighting liquidity, volatility and seasonal patterns. Use the filters to explore different timeframes.
          </p>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-midnight border border-slate rounded-lg p-4">
              <Image
                src="/forecasts/btc_sarima2025.png"
                alt="BTC SARIMA forecast 2025"
                width={400}
                height={300}
                className="rounded"
              />
              <h3 className="text-lg font-serif text-gold mt-2">SARIMA Forecast</h3>
            </div>
            <div className="bg-midnight border border-slate rounded-lg p-4">
              <Image
                src="/forecasts/btc_hw2025.png"
                alt="BTC Holt-Winters forecast 2025"
                width={400}
                height={300}
                className="rounded"
              />
              <h3 className="text-lg font-serif text-gold mt-2">Holt-Winters Forecast</h3>
            </div>
            <div className="bg-midnight border border-slate rounded-lg p-4">
              <Image
                src="/forecasts/btc_prophet2025.png"
                alt="BTC Prophet forecast 2025"
                width={400}
                height={300}
                className="rounded"
              />
              <h3 className="text-lg font-serif text-gold mt-2">Prophet Forecast</h3>
            </div>
          </div>
          <table className="min-w-full mt-4 text-slate">
            <thead>
              <tr>
                <th className="border-b border-slate px-4 py-2 text-left">Model</th>
                <th className="border-b border-slate px-4 py-2 text-left">MAPE</th>
                <th className="border-b border-slate px-4 py-2 text-left">RMSE</th>
                <th className="border-b border-slate px-4 py-2 text-left">Directional Accuracy</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border-b border-slate px-4 py-2">SARIMA</td>
                <td className="border-b border-slate px-4 py-2">5.2%</td>
                <td className="border-b border-slate px-4 py-2">0.18</td>
                <td className="border-b border-slate px-4 py-2">72%</td>
              </tr>
              <tr>
                <td className="border-b border-slate px-4 py-2">Holt-Winters</td>
                <td className="border-b border-slate px-4 py-2">6.0%</td>
                <td className="border-b border-slate px-4 py-2">0.21</td>
                <td className="border-b border-slate px-4 py-2">68%</td>
              </tr>
              <tr>
                <td className="border-b border-slate px-4 py-2">Prophet</td>
                <td className="border-b border-slate px-4 py-2">4.7%</td>
                <td className="border-b border-slate px-4 py-2">0.16</td>
                <td className="border-b border-slate px-4 py-2">75%</td>
              </tr>
            </tbody>
          </table>
        </section>
        {/* BVMT stocks section */}
        <section>
          <h2 className="text-2xl font-serif text-gold mb-4">BVMT Stocks Dashboard</h2>
          <PowerBIFrame url={stocksUrl} title="Stocks Dashboard" />
          <p className="text-slate mb-4">
            Interpretation: The BVMT dashboard summarises key indicators for the Tunisian stock market, including close prices, volume, rolling volatility, year‑to‑date performance and seasonality patterns. Use the sector and issuer filters to dive into specific segments.
          </p>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-midnight border border-slate rounded-lg p-4">
              <Image
                src="/forecasts/stocks_sarima2025.png"
                alt="Stocks SARIMA forecast 2025"
                width={400}
                height={300}
                className="rounded"
              />
              <h3 className="text-lg font-serif text-gold mt-2">SARIMA Forecast</h3>
            </div>
            <div className="bg-midnight border border-slate rounded-lg p-4">
              <Image
                src="/forecasts/stocks_hw2025.png"
                alt="Stocks Holt-Winters forecast 2025"
                width={400}
                height={300}
                className="rounded"
              />
              <h3 className="text-lg font-serif text-gold mt-2">Holt-Winters Forecast</h3>
            </div>
            <div className="bg-midnight border border-slate rounded-lg p-4">
              <Image
                src="/forecasts/stocks_prophet2025.png"
                alt="Stocks Prophet forecast 2025"
                width={400}
                height={300}
                className="rounded"
              />
              <h3 className="text-lg font-serif text-gold mt-2">Prophet Forecast</h3>
            </div>
          </div>
          <table className="min-w-full mt-4 text-slate">
            <thead>
              <tr>
                <th className="border-b border-slate px-4 py-2 text-left">Model</th>
                <th className="border-b border-slate px-4 py-2 text-left">MAPE</th>
                <th className="border-b border-slate px-4 py-2 text-left">RMSE</th>
                <th className="border-b border-slate px-4 py-2 text-left">Directional Accuracy</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border-b border-slate px-4 py-2">SARIMA</td>
                <td className="border-b border-slate px-4 py-2">7.3%</td>
                <td className="border-b border-slate px-4 py-2">0.22</td>
                <td className="border-b border-slate px-4 py-2">70%</td>
              </tr>
              <tr>
                <td className="border-b border-slate px-4 py-2">Holt-Winters</td>
                <td className="border-b border-slate px-4 py-2">8.1%</td>
                <td className="border-b border-slate px-4 py-2">0.25</td>
                <td className="border-b border-slate px-4 py-2">65%</td>
              </tr>
              <tr>
                <td className="border-b border-slate px-4 py-2">Prophet</td>
                <td className="border-b border-slate px-4 py-2">6.8%</td>
                <td className="border-b border-slate px-4 py-2">0.20</td>
                <td className="border-b border-slate px-4 py-2">73%</td>
              </tr>
            </tbody>
          </table>
        </section>
      </main>
      <Footer />
    </>
  );
}