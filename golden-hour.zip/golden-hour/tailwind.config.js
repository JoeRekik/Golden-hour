/**
 * Tailwind configuration for the Golden Hour project.
 *
 * This file defines custom colors and fonts that reflect the
 * Golden Hour brand. The palette uses gold, midnight, slate and
 * white, while Inter and Playfair Display provide a modern yet
 * elegant typographic feel. Tailwind will scan files in the
 * `pages` and `components` directories to generate utility
 * classes used throughout the site.
 */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx}',
    './components/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        gold: '#E0B000',
        midnight: '#0F1420',
        slate: '#8693A6',
        white: '#FFFFFF',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        serif: ['Playfair Display', 'serif'],
      },
    },
  },
  plugins: [],
};