/**
 * PostCSS configuration.
 *
 * This configuration enables Tailwind CSS and autoprefixer when
 * building the project. These plugins will process the CSS and
 * generate the necessary classes defined in the Tailwind config.
 */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};