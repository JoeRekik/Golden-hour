/**
 * Footer component.
 *
 * Provides site-wide information at the bottom of every page,
 * including a copyright notice, a disclaimer, and links to
 * additional legal pages. Colours come from the Tailwind
 * configuration, and the date is calculated dynamically.
 */
export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-midnight text-slate py-8">
      <div className="container mx-auto text-center text-sm px-4">
        <p className="mb-2">© {year} Golden Hour – Educational analytics only. Not investment advice.</p>
        <div className="space-x-4">
          <a href="/legal" className="hover:text-gold">Terms</a>
          <a href="/legal" className="hover:text-gold">Privacy</a>
          <a href="/legal" className="hover:text-gold">Risk Warning</a>
        </div>
      </div>
    </footer>
  );
}