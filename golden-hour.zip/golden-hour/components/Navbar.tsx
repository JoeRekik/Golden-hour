import Link from 'next/link';

/**
 * Navigation bar component.
 *
 * Displays the project name on the left and navigation links on
 * the right. Colours and fonts are drawn from the Tailwind
 * configuration to ensure brand consistency. Links change color on
 * hover to provide a subtle interactive cue.
 */
export default function Navbar() {
  return (
    <nav className="bg-midnight text-white py-4">
      <div className="container mx-auto flex items-center justify-between px-4">
        {/* Logo or project name */}
        <span className="font-serif text-gold text-2xl">Golden Hour</span>
        {/* Navigation links */}
        <div className="space-x-4 text-sm">
          <Link href="/" className="hover:text-gold">Home</Link>
          <Link href="/forms" className="hover:text-gold">Forms</Link>
          <Link href="/pricing" className="hover:text-gold">Pricing</Link>
          <Link href="/dashboards" className="hover:text-gold">Dashboards</Link>
          <Link href="/about" className="hover:text-gold">About</Link>
        </div>
      </div>
    </nav>
  );
}